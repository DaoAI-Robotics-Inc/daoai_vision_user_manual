Excercise
=============

https://docs.pickit3d.com/en/latest/exercises/index.html

This section covers the excercise for the vision engineer to practice the usage of the system

.. toctree::
   :numbered:
   :maxdepth: 1
   :caption: Contents

   snapshot/overview
   link/overview
   build-operator-view/overview
   build-3d-mod-finder/overview
   3d-mod-finder-picking/overview
   mono-3d-picking/overview