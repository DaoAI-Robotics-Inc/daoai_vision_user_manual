Build a operator view
============

