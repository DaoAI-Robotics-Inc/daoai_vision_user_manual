Build depth mod finder detection pipeline
============

