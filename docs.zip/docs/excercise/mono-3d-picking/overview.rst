Build 3d mod finder detection pipeline
============

