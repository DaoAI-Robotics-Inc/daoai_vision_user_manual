3D calibration overview
===========