Depth Mod Finder
===========

It used the depth information to find the object and locate the object in 3d space.