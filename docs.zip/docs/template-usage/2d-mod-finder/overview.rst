Gray Mod Finder
===========

It used the gray image to find the object in 2d, then project into 3d space.