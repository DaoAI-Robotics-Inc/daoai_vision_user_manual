Auto part ordered picking 
==================
