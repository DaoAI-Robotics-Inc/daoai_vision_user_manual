Cylinder shape object picking in deep box
===========
