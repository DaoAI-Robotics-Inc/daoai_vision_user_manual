Daoai Laser Camera
==================


Physical Camera Wire Connection
~~~~~~~~~~~~~


Connect the camera via Webpage
~~~~~~~~~~~~~

Config camera from webpage
~~~~~~~~~~~

Connect the camera via DaoAI Vision Studio
~~~~~~~~~~~~~


Connect the virtual camera via DaoAI Vision Studio
~~~~~~~~~~~~~


Network configuration
~~~~~~~~~~


Common Issues
~~~~~~~~~~~~~~