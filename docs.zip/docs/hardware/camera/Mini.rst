Daoai Mini Camera
=================

Physical Camera Wire Connection
~~~~~~~~~~~~~

Connect the camera via DaoAI Vision Studio
~~~~~~~~~~~~~

Connect the virtual camera via DaoAI Vision Studio
~~~~~~~~~~~~~

Use Camera with Camera Node
~~~~~~~~~~~~~~~~~~~~


Common Issues
~~~~~~~~~~~~~~
* USB connection
* Image quality