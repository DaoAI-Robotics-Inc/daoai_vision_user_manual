Hardware
=========


This section covers the hardware components for the whole system

.. toctree::
   :maxdepth: 2

   camera/index 
   robot/index
