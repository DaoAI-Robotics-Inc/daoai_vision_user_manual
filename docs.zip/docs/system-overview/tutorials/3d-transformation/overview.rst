3D Transformation Example
===============