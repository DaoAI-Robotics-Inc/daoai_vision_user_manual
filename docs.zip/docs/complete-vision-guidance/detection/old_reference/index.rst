Templates of picking flowchart
==============================

.. toctree::
   :caption: Content

   Order Picking