Picking
=========

This section will cover all the steps to setup the picking procedure with DaoAI Vision Studio.