2D Calibration by associating robot object frame with camera frame
==================

similar to this (https://docs.pickit3d.com/en/latest/documentation/calibration/multi-poses-calibration.html)