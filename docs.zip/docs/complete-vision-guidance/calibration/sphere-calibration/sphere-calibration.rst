Sphere Calibration
=======================