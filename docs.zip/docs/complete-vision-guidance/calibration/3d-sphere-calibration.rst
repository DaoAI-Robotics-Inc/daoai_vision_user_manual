Sphere Calibration
===============
Follow the same pattern as Circle board calibration 