Validating 2D calibration result 
====================

Follow this page (https://docs.pickit3d.com/en/latest/documentation/calibration/calibration-validation-qualitative.html)