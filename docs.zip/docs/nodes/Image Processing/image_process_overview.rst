Overview
------------------------

Input 
~~~~~~~~~~~~~~~~~~~~~~~~~~~

Image_In (type:Image) : Input image for image process operations.  

Output
~~~~~~~~~~~~~~~~~~~~~~~~~~

imageOutput (type:Image) : Output image after perfroming different operations on the input image.

