Scene Crop Node
==========================

The Scene Crop Node uses segmentation results to crop a Point Cloud and output a vector of clouds corresponding to each segment.

.. image:: ../../_static/images/3d_process/scene_crop.PNG
   :width: 100%

.. toctree::
   :maxdepth: 1

   scene_crop_overview
   scene_crop_procedure
   