Overview 
=========================

nput 
-----------------------------

Point Cloud: the input point cloud to be processed.

Output
----------------------------

outputCloud: the output point cloud after processing.
depthMap: the depth image of the processed point cloud
image: the rgp image of the processed point cloud
referenceFrame: the reference coordinate defined in 3d process node, used as input of other nodes
mergePoses: transformation applied to the second point cloud, when merging two point cloud

