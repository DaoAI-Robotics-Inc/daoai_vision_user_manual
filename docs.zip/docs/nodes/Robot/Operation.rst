Robot Operation
========================