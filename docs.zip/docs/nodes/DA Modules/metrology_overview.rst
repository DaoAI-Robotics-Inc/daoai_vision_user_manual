Overview
===============

Reference Fixture 
--------------------

Please refer to Reference Fixture System


Interactive Display 
---------------------
	
User may only be able to edit or add features after click "Show Interactive Display"

Output 
-----------------

* allTolerancesPassed: (DataType:Bool) a boolean value indicating if all tolerances are passed
	
* numPassedTolerances: (DataType:Int) number of passed tolerance
	
* numWarningTolerances: (DataType:Int) number of warning tolerance
	
* numFailedTolerances: (DataType:Int) number of fail tolerance
	
* toleranceResult/tolerance_name['']: (DataType:Double) the actual value of the tolerance
