Mod Finder Node 
==========

Search edgel model on gray image. 



.. toctree::
   :maxdepth: 1

   mod_finder_overview
   mod_finder_procedure
   mod_finder_detail



