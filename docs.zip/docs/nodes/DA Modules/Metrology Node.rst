Metrology Node
=========


	Define, Detect or Calculate features such as edge, circle, and point on a gray image.
	Calculate value information such as length of segment and radius of circle and arc. 

 .. image:: images/metrology_0.jpg
	:scale: 60%
	
 .. image:: images/metrology_1.jpg
	:scale: 60%


.. toctree::
   :maxdepth: 1

   metrology_overview
   metrology_procedure

