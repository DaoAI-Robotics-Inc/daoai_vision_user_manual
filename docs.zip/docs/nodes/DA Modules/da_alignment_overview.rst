Overview
============

Input 
-----------
	Scene Cloud: (DataType: Cloud)Scene point cloud.
	Model Cloud: (DataType: Cloud)Model point cloud.
	Hypothesis: (DataType: Pose)The initial guess for the pose, usually obtained from reconstruct node.

Output 
-----------------
	poses: (DataType: Pose)The aligned poses, a vector of 3D pose.

