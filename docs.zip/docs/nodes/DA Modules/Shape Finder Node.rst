Shape Finder Node 
=========


Search shape on gray image using edge based searching. 
	
 .. image:: images/shape_finder_3.jpg
	:scale: 90%
	:align: center

.. toctree::
   :maxdepth: 1

   shape_finder_overview
   shape_finder_procedure


