Procedure of Using Measurement Node
==========================================

1. Set input Image.
2. Open interactive display
3. Define Markers
4. Run the node.

