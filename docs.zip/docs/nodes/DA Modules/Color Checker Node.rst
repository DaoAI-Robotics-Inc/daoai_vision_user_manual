Color Checker Node 
=========

Do color matching or color segmentation on a color image.


.. toctree::
   :maxdepth: 1

   color_checker_overview
   color_checker_procedure