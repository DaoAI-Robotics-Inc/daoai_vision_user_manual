Flowchart Control 
==================

Normally, a flowchart runs sequentially from top to bottom. To have a more programmable flowchart we use flowchart control node to alter the order of flowchart run.


.. toctree::
	:maxdepth: 1
	
	Break Node
	Condition Node
	Constant Node
	Continue Node
	Flowchart Node
	Halt Node
	Loop Node
	Switch Node