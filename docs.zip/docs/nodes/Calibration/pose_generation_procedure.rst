Procedure of using the Pose Generation Node
===============================================

Usually inside an Auto Calibration flowchart to generate a number of poses.

The following procedure provides a basic methodology for using the Pose Generation Node:

1. Set up the input for the node
2. Adjust parameters to correctly config the process type
3. The output of the poses can be used for Robot Write Node to tell the robot where to go