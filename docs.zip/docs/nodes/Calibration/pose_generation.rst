Pose Generation node
==========================

This node generates a set of robot poses with a specific pattern which then can be used for data capturing used for Calibration Node, DA Calibration Node or Sphere Calibration Node.   

.. toctree::
   :caption: Content

   pose_generation_overview
   pose_generation_procedure


