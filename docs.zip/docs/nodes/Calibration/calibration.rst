Calibration node
==========================

This node perfrorms 3D robot calibration using chessboard or circle grid as the calibration tool. This node can be run in three different modes.  

.. toctree::
   :caption: Content

   calibration_overview 
   calibration_procedure 

