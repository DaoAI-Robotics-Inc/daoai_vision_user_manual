Sphere Calibration node
==========================

This node perfrorms 3D robot calibration using a sphere as the calibration tool. This node can be run in three different modes.  

.. toctree::
   :caption: Content

   shpere_calibration_overview
   sphere_calibration_procedure
