Load Recipe Node
=======================
 
This node allows user to load recipe automatically. For more information about the recipe, refer to recipe section.
This node contains a table of recipe names. Users can add/remove recipe names in the table, when the node is run,
it loads the recipe with the input index.

.. image:: ../../_static/images/util/load_recipe.PNG
   :width: 100%

Input
________________________

* Index : the index in node's recipe table, corresponding recipe will be loaded

