Count Node
========================

A counter node that increases its counter every time the node has been run, usually used in loop control

output
------------------
count : number of time the count node has been run, note that the rest button on top of flowchart to reset the counter to 0

