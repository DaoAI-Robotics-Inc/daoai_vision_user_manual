How to deal with workspace upgrading
============

When there is a upgrading feature