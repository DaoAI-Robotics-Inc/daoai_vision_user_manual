How to Collect a Dataset
========================